export class Pessoa {
    nome: string;
    email: string;
    telefone: string;
  
    constructor(nome: string, email: string, telefone: string) {
      this.nome = nome;
      this.email = email;
      this.telefone = telefone;
    }
  }
